import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

public class BoatNamesHashTable {

	public static void main(String args[])
	{
		Hashtable<String, String> boats = new Hashtable <String, String>();

		Scanner scn = new Scanner(System.in);

		System.out.println("Please enter the number of boats in the marina: ");

		int numBoats = scn.nextInt();

		String boatName;
		String license;

		for(int i = 0; i < numBoats; i++)
		{
			System.out.println("Please enter the name of boat #"  + (i+1) );
			boatName = scn.next();

			System.out.println("Please enter the boat license for boat #" + (i+1));
			license = scn.next();
			
			boats.put(boatName, license);
			
		}

		Enumeration<String> enumeration = boats.elements();

		while(enumeration.hasMoreElements())
		{
			System.out.println("Hashtable values: " + enumeration.nextElement());

		}

		System.out.println("Is boats hashtable empty: " + boats.isEmpty());

		System.out.println("Size of hashtable in Java: " + boats.size());

		boats.clear();



	}

}
