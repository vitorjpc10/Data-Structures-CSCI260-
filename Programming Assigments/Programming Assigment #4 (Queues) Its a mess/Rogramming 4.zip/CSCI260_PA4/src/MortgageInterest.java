import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MortgageInterest {
	
	public static double interestCalcFirst(double homeValue,double downPayment, double interestRate)
	{
		double newHomeValue = homeValue - downPayment;
		double newInterest = (interestRate/100) * newHomeValue;
		
		return newInterest;
	}
	
	public static double interestCalcSecond(double homeValue, double interestRate)
	{
		
		double newInterest = (interestRate/100) * homeValue;
		
		return newInterest;
	}
	
	
	public static void main (String[] args)
	{
	
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Welcome to the Mortgage Interest Calculator:\n");
		
		System.out.println("Please insert your home value: \n");
		double homeValue = sc.nextDouble();
		
		System.out.println("Please insert your down payment: \n");
		double downPay = sc.nextDouble();
		
		System.out.println("Please insert the interest rate: \n");
		double interestRate = sc.nextDouble();
		
		System.out.println("Please insert you monthly principle: \n");
		double principle = sc.nextDouble();
		
		System.out.println("The new interest payment is... $" + interestCalcFirst(homeValue, downPay, interestRate));
		
		double interestPrinciple = interestCalcFirst(homeValue, downPay, interestRate) + principle;
		
		double queueValue = (homeValue - downPay) - interestPrinciple;
		
		System.out.println("New home Value is: " + queueValue);
		
		Queue<Double> queue = new LinkedList<Double>();
		
		queue.add(queueValue);
		
		//System.out.println(queue.poll());
		Double newHomeValue;
		
		
		for(int i = 0; i < 12; i++)
		{
			
			if(i == 0)
			{
			interestPrinciple = interestCalcFirst(homeValue, downPay, interestRate) + principle;
			
			queueValue = (homeValue - downPay) - interestPrinciple;
			
			System.out.println("The new home Value is: " + queueValue);
			
			queue.add(queueValue);
			
			System.out.println("The interest Payment for the month " + (i+1) + " is: "  + interestCalcFirst(homeValue, downPay, interestRate));
			
			homeValue = queueValue;
			}
			
			else
			{
				interestPrinciple = interestCalcSecond(homeValue, interestRate) + principle;
				
				queueValue = (homeValue - downPay) - interestPrinciple;
				
				System.out.println("The new home Value is: " + queueValue);
				
				queue.add(queueValue);
				
				System.out.println("The interest Payment for the month " + (i+1) + " is: "  + interestCalcSecond(homeValue, interestRate));
				
				homeValue = queueValue;
			}
			
		}
		
		
	}
	
	
	
}
