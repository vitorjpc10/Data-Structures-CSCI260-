import java.util.Scanner;
import java.util.Stack;

public class Retirement_Estimate_401k 
{
	
	public static double investCalc(double newAmount,double interest)
	{
		double percentage = (interest/100);
		//System.out.println("The percentage is... " + percentage);
		
		return ((newAmount * percentage) + newAmount);
	}
	
	public static void main(String args[])
	{
		
	

	Scanner sc = new Scanner(System.in);
	
	System.out.println("Welcome to the 401k Retirement Estimate" + "\n");
	
	System.out.println("Please enter the amount you wish to contribute each year:");
	int amount = sc.nextInt();
	
	System.out.println("Please enter the percentage of interest that you think you will earn each year on average:");
	int interest = sc.nextInt();
	
	//System.out.println("The calculated amount for $" + amount + " and the interest of " + interest + " is: $" + investCalc(amount,interest));
	
	Stack stackR = new Stack();
	double newAmount = investCalc(amount, interest);
	String finalValue;
	
	
	for(int i = 0; i < 30; i++)
	{
		
		finalValue = String.format("%.2f", newAmount);
		
		stackR.push(finalValue);
		
		newAmount = investCalc(newAmount + amount, interest);
		
		//System.out.println(stackR);
		
	}
	
	int years = 30;
	
	while(!stackR.isEmpty())
	{
		System.out.println("Here are your total earnings for the past " + years + " years: $" + stackR.pop());
		years--;
	}
	
	}
}
