import java.util.Stack;

public class StackDemo1
{
	public static void main(String args[])
	{
		
		Stack nyitL = new Stack();
		
		nyitL.push("NYC");
		nyitL.push("OLD WESTBURY");
		nyitL.push("VANCOUVER");
		nyitL.push("NANJING");
		nyitL.push("CENTRAL ISLIP");
		nyitL.push("ABU DHABI");
		nyitL.push("JONESBORO");

		System.out.println("Removed object is: " + nyitL.pop());
		
		System.out.println("Elements after remove: " + nyitL);
		
		System.out.println("Element on top is: " + nyitL.peek()); 
		
	}
	
}
