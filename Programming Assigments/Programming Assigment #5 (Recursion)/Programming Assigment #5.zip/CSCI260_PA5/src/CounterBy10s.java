import java.util.Scanner;

public class CounterBy10s 
{

	
	
	public static void counter10(int max, int n)
	{
		
		if (n > max)
			return;
		else
		{
		System.out.println("The next number is: " + n);
		counter10(max, n+10);
		}
		
	}
	
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the max amount you want your number to go up to: ");
		int userM= sc.nextInt();
		
		System.out.println("Please enter the number you want to start counting 10s from:");
		int userN = sc.nextInt();
		
		counter10(userM, userN);
		
	}
	
}
