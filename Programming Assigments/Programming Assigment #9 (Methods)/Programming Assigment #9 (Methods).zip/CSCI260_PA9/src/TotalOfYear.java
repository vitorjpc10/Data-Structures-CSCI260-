
public class TotalOfYear
{

	
	public static void totalOfYear()
	{
	
	 double retvariable = ReturnMethod.returnamount(62,34,12,45);

     

     System.out.println(retvariable);

    

     double yearlytotal = retvariable * 365;

    

     System.out.println("The total for the year is:" + yearlytotal);
     
	}
}
