
public class ExternalMethod {

	public static void externalMethod()
	{
		System.out.println("This is how to call an EXTERNAL method!");
	}
	
	
}
