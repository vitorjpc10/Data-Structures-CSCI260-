
public class MethodsApp
{

	 static void internalMethod()

	    {

	        System.out.println("This is how to call a method!");

	    }
	
	public static void main(String args[])
	{
		internalMethod();
		ExternalMethod.externalMethod();
		CompoundInterestCalc.interestcalc();
		ParameterMethod.parametercalc(10, 20, 30, 40);
		ReturnMethod.returnamount(10, 20, 30, 40);
		TotalOfYear.totalOfYear();
		MenuClass.runmenu();
		
	}
	
}
