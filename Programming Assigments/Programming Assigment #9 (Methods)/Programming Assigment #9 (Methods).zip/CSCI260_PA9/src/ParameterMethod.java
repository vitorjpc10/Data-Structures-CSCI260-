
public class ParameterMethod
{

	 public static void parametercalc (int a, int b, double c, double d)

	    {

	       

	        double total = a + b + c + d;

	         

	        System.out.println("The sum of the passed in parameters is "+ total);

	              

	       

	    }
	
}
