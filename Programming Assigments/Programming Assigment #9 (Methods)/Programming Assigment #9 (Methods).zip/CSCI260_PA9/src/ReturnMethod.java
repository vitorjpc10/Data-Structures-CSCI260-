
public class ReturnMethod 
{	 

	    static double returnamount (int a, int b, double c, double d)

	    {

	     

	        double total = a + b + c + d;

	         

	        return total;

	              

	    }
	
}
