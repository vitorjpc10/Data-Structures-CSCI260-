import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class FoodVegetableOrder {

	public static void main(String args[]) throws IOException
	{



		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		ArrayList<String> cart = new ArrayList<String>();

		String[] vegetableSupply = {"Potato", "Carrot", "Onion", "Lettuce", "Corn"};

		System.out.println("From the following selection of vegetables which one would you like to order into your shopping cart? ");


		for( String name : vegetableSupply ) 
		{
			System.out.print( name );
			System.out.print(", ");
		}
		
		System.out.println("\n");

		String vegetableOrder = input.readLine();
		
		//Do while loop to check if user input is one of the available vegetables
		
		System.out.println("How many of that vegetable would you like to order?");
		String stringAmount = input.readLine();
		int vegetableAmount = Integer.parseInt(stringAmount);
		
		for(int i = 0; i < vegetableAmount; i++)
		{
			cart.add(vegetableOrder);
		}

		System.out.println("Your cart currently has: " + cart);
		
		System.out.println("Please enter an idex of the item you would like to remove:");
		int removalIndex = Integer.parseInt(input.readLine());
		
		cart.remove(removalIndex);
		
		System.out.println("After the removal at index "+ removalIndex + " your cart currently has: " + cart);
		
		//while()

	}

}
