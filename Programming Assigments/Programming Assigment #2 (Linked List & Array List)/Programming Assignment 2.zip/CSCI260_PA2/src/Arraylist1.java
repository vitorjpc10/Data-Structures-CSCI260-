import java.util.ArrayList;

public class Arraylist1 
{
	public static void main(String args[])
	{

		ArrayList<String> arrayObj = new ArrayList<String>();

		arrayObj.add("Bob");
		arrayObj.add("Mary");
		arrayObj.add("John");
		arrayObj.add("Amy");
		arrayObj.add("Steve");

		System.out.println("The array list currently has the following objects: " + arrayObj);

		arrayObj.add(4, "Vitor");
		arrayObj.add(1, "Michael");

		arrayObj.remove("Bob");
		arrayObj.remove("Amy");


		System.out.println("Now the array list currently has the following objects: " + arrayObj);

		arrayObj.remove(2);

		System.out.println("After removing object at index 2, the array list currently has the following objects: " + arrayObj);
	}

}

