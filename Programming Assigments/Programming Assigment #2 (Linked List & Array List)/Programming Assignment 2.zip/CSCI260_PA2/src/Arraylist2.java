import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Arraylist2 
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		ArrayList<String> arrayList = new ArrayList<String>();

		arrayList.add("USA");
		arrayList.add("Brazil");
		arrayList.add("Canada");
		arrayList.add("Mexico");
		arrayList.add("England");
		arrayList.add("Iceland");
		arrayList.add("Moroco");
		arrayList.add("Australia");
		arrayList.add("China");
		arrayList.add("Poland");

		System.out.println("Vacation Country Advisor!!");
		System.out.println("Enter your name");
		String userName = input.readLine();
		int nameLength = userName.length();

		while (nameLength == 0)
		{
			System.out.println("No name inputed, please enter a name");
			userName = input.readLine();
			nameLength = userName.length();
		}

		int vacationIndex = nameLength % arrayList.size();
		System.out.println("vacationIndex: " + vacationIndex);

		System.out.println("\nYour name is " + userName + ", its length is " + nameLength + " characters, \n" + "given that we suggest that you travel to the country of " + arrayList.get(vacationIndex));


	}
}
