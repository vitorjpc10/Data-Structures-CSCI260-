import java.util.LinkedList;
/**
 *
 * @author Michael
 */
public class LinkedList2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<String> lList = new LinkedList<String>();
        
        lList.add("Apple");
        lList.add("Pear");
        lList.add("Banana");
        lList.add("Orange");
        lList.add("Peach");
        
        System.out.println("LinkedList contains : " + lList);
        
        Object object = lList.removeFirst();
        System.out.println(object + " has been removed from the first index of LinkedList");
        System.out.println("LinkedList now contains :" + lList);
        
        object = lList.removeLast();
        System.out.println(object + " has been removed from the last index of LinkedList");
        
        System.out.println("LinkedList now contains : " + lList);
    }
    
}
