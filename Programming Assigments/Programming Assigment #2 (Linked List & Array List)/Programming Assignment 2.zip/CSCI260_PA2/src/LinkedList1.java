import java.util.*;
/**
 *
 * @author Michael
 */
public class LinkedList1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<String> linkedlist = new LinkedList<String>();
        
        linkedlist.add("Potato");
        linkedlist.add("Onion");
        linkedlist.add("Carrot");
        linkedlist.add("Lettuce");
        linkedlist.add("Broccoli");
        
        System.out.println("Linked List Content: " + linkedlist);
        
        linkedlist.addFirst("Artichoke");
        linkedlist.addLast("Corn");
        System.out.println("LinkedList Content after addition: " + linkedlist);
        
        Object firstvar = linkedlist.get(0);
        System.out.println("First element: " + firstvar);
        linkedlist.set(0, "Changed first vegetable");
        Object firstvar2 = linkedlist.get(0);
        
        System.out.println("First element after update by set method: " + firstvar2);
        
        linkedlist.removeFirst();
        linkedlist.removeLast();
        System.out.println("LinkedList after deletion of first and last element: " + linkedlist);
        
        linkedlist.add(0, "Celery");
        linkedlist.remove(2);
        System.out.println("Final Content: " + linkedlist);
    }
    
}
