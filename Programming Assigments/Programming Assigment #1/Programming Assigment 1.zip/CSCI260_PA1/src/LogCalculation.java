import java.lang.Math;

public class LogCalculation {

	public static double log5(int x)
	{
		double ans = (Math.log(x) / Math.log(5));
		return ans;

	}

	public static void main(String[] args) {

		int[] values = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

		for(int x: values)
		{
			System.out.println("The log base 5 of '" + x + "' is: " + log5(x));
		}



	}
}

